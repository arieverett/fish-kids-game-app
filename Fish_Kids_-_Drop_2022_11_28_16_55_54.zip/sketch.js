//here is where i set my global variables and any booleans
var x
var y
var appleX = 0
var appleY = 0
var img

//i found this through youtube, preload is a common function to call items in your repo, so i called the fish image here. i had some sounds as a background soundtrack and to signal if you did it correctly or incorrectly, but removed them in the end because they were distracting more than helping the user
function preload() {
  img = loadImage("fish2.png");
  //lose = loadSound('try-again.mp3');
  //win = loadSound('win.mp3');
  //song = loadSound('underwater music.mp3')
  //song.loop()
  
}

//i set the mouse click and drag function of an object here
function mouseDragged() {
  if ((mouseX > appleX - 50) && (mouseX < appleX + 50)) {
    if ((mouseY > appleY - 50) && (mouseY < appleY + 50)) {
      appleX = mouseX;
      appleY = mouseY
    }
  }
}

//i used the setup function to create the canvas for the game
function setup() {
  createCanvas(800, 450);
  //song.play()
  //song.setVolume(1.0)

}


//i used the draw function to draw the map of the game and show instructions
function draw() {
    
  button = createButton('HOME')
  button.position(350,475)
  button.size(100)
  button.mousePressed(page_home)
  
  background('#87CEEB')
  
  //land left
  fill('green')
  rect(0, 320, 350, 130)
  
  //water center
  fill('blue')
  rect(350, 350, 100, 130)
  
  //land right
  fill('green')
  rect(450, 320, 350, 130)
  
  //trees
  //large left
  fill('brown')
  rect(90, 150, 10, 170)
  fill('green')
  rect(30, 120, 150, 30)
  
  //small left
  fill('brown')
  rect(200, 210, 10, 110)
  fill('green')
  rect(120, 180, 350, 30)
  
  //large right
  fill('brown')
  rect(600, 100, 10, 220)
  fill('green')
  rect(300, 70, 400, 30)
  
  //large right
  fill('brown')
  rect(475, 300, 10, 20)
  fill('green')
  rect(425, 280, 150, 30)
  
  textSize(15);
  textAlign(RIGHT, RIGHT)
  textStyle(BOLD)
  textFont('Helvetica')
  fill('black')
  text('Help your fish friend, Fish Kid!\nClick, drag & drop him into the water!\nBe careful, avoid the land and trees!', 790, 20);

//this starts an if statement that will gamify and provide feedback to the user when they correctly or incorrectly proceed with the game
  image(img, appleX, appleY, 50, 50);
  
  if ((appleX > 320) && (appleX < 425)) {
    if ((appleY > 340) && (appleY < 450)) {
      fill('yellow')
      textAlign(CENTER, CENTER);
      text("Great job, Fish Kid!\nClick home to play another game or play again", 400, 150);
      //win.play()
      
    }
  }
    
  if ((appleX > 0) && (appleX < 320)) {
    if ((appleY > 275) && (appleY < 450)) {
      fill('red');
      textAlign(CENTER, CENTER);
      text("That's not water, Fish Kid!\nTry again", 400, 150); 
      //lose.play();
    }
  }
  
  if ((appleX > 425) && (appleX < 800)) {
    if ((appleY > 275) && (appleY < 450)) {
      fill('red');
      textAlign(CENTER, CENTER);
      text("That's not water, Fish Kid!\nTry again", 400, 150);
      //lose.play();
    }
  }  
  
  //tree large left
  if ((appleX > 0) && (appleX < 175)) {
    if ((appleY > 75) && (appleY < 125)) {
      fill('red');
      textAlign(CENTER, CENTER);
      text("Don't hit the trees, Fish Kid!\nTry again", 400, 150);
      //lose.play();
    }
  } 
  
    //tree large left trunk
  if ((appleX > 55) && (appleX < 85)) {
    if ((appleY > 125) && (appleY < 300)) {
      fill('red');
      textAlign(CENTER, CENTER);
      text("Don't hit the trees, Fish Kid!\nTry again", 400, 150);
      //lose.play();
    }
  }
  
    //tree small left
  if ((appleX > 75) && (appleX < 460)) {
    if ((appleY > 140) && (appleY < 200)) {
      fill('red');
      textAlign(CENTER, CENTER);
      text("Don't hit the trees, Fish Kid!\nTry again", 400, 150);
      //lose.play();
    }
  }
  
      //tree small left trunk
  if ((appleX > 160) && (appleX < 190)) {
    if ((appleY > 200) && (appleY < 275)) {
      fill('red');
      textAlign(CENTER, CENTER);
      text("Don't hit the trees, Fish Kid!\nTry again", 400, 150);
      //lose.play();
    }
  }
  
  //tree large right
  if ((appleX > 250) && (appleX < 700)) {
    if ((appleY > 25) && (appleY < 100)) {
      fill('red');
      textAlign(CENTER, CENTER);
      text("Don't hit the trees, Fish Kid!\nTry again", 400, 150);
      //lose.play();
    }
  }
  
    //tree large right trunk
  if ((appleX > 550) && (appleX < 610)) {
    if ((appleY > 100) && (appleY < 280)) {
      fill('red');
      textAlign(CENTER, CENTER);
      text("Don't hit the trees, Fish Kid!\nTry again", 400, 150);
      //lose.play();
    }
  }
  
    //tree small right
  if ((appleX > 375) && (appleX < 550)) {
    if ((appleY > 235) && (appleY < 275)) {
      fill('red');
      textAlign(CENTER, CENTER);
      text("Don't hit the trees, Fish Kid!\nTry again", 400, 150);
      //lose.play();
    }
  }
  
}

//i used this to create a home button for easy and continuous functionality throughout the game
function page_home() {
  window.open('https://editor.p5js.org/arieverett/full/XRgiijiGI')
}