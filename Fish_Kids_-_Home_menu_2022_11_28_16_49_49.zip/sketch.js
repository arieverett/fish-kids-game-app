let image_background
let lThreshold = 50
let song
let volumeSlider

function preload() {
  image_background = loadImage('assets/background.jpg')
  
  song = loadSound('underwater music.mp3')
  song.loop()
}


function setup() {
  createCanvas(800, 450)

  image(image_background, 0,0, width, height)
  
  song.play()
  song.setVolume(1.0)

  noLoop()
}

function draw() {  
  title1 = createDiv('FISH KIDS')
  title1.style('font-size', '50px')
  title1.style('color', '#FF3300')
  title1.position(275, 30)
  title1.style('font-family', 'helvetica')
  title1.style('font-style', 'italic')
  title1.style('font-weight', 'bold')
  
  title2 = createDiv ('Welcome aboard, Fish Kid!<br>Tap on the game you want to       play below:')
  title2.style('font-size', '20px')
  title2.style('color', '#000000')
  title2.position(205, 100)
  title2.style('font-family', 'helvetica')
  //title2.style('font-style', 'italic')
  title2.style('font-weight', 'bold')
  title2.style('text-align', "center")
  
  button1 = createButton('TRACE')
  button1.position(200,225)
  button1.size(100)
  button1.mousePressed(page_trace)
  
  button2 = createButton('FEED')
  button2.position(350,225)
  button2.size(100)
  button2.mousePressed(page_feed)
  
  button3 = createButton('DROP')
  button3.position(500,225)
  button3.size(100)
  button3.mousePressed(page_drop)
  
  button4 = createButton('SETTINGS')
  button4.position(350,375)
  button4.size(100)
  button4.mousePressed(page_settings)
  
  button5 = createButton('HOME')
  button5.position(350,400)
  button5.size(100)
  button5.hide()
  button5.mousePressed(go_home)

}

function page_settings() {  
  button1.hide()
  button2.hide()
  button3.hide()
  button4.hide()
  button5.show()
  title1.hide()
  title2.hide()

  titleContrast = createDiv ('Contrast:')
  titleContrast.style('font-size', '20px')
  titleContrast.style('color', '#000000')
  titleContrast.position(355, 70)
  titleContrast.style('font-family', 'helvetica')
  //title2.style('font-style', 'italic')
  titleContrast.style('font-weight', 'bold')
  titleContrast.style('text-align', "center")
  
  titleBrightness = createDiv ('Brightness:')
  titleBrightness.style('font-size', '20px')
  titleBrightness.style('color', '#000000')
  titleBrightness.position(340, 170)
  titleBrightness.style('font-family', 'helvetica')
  //title2.style('font-style', 'italic')
  titleBrightness.style('font-weight', 'bold')
  titleBrightness.style('text-align', "center")
  
  titleVolume = createDiv ('Volume:')
  titleVolume.style('font-size', '20px')
  titleVolume.style('color', '#000000')
  titleVolume.position(355, 270)
  titleVolume.style('font-family', 'helvetica')
  //title2.style('font-style', 'italic')
  titleVolume.style('font-weight', 'bold')
  titleVolume.style('text-align', "center")
  
  contrastSlider = createSlider(-30, 30, 0, 1);
  contrastSlider.position(330, 100);
  
  exposureSlider = createSlider(-30, 30, 0, 1);
  exposureSlider.position(330, 200);
  
  volumeSlider = createSlider(0, 1, 0.5, .01);
  volumeSlider.position(330, 300);
  song.setVolume(volumeSlider.value)
  
  let contrast = contrastSlider.value();
  let exposure = exposureSlider.value();
  
  for(let y = 0 ; y < image_background.height; y += scale){
  for(let x = 0; x < image_background.width; x += scale){
  
  let index = (y*image_background.width+x)*4;
  let r = image_background.pixels[index+0];
  let g = image_background.pixels[index+1];
  let b = image_background.pixels[index+2];
  // relative luminance
  let l = 0.2126*r + 0.7152*g + 0.0722*b
  
  // contrast adjustment - if above or below threshold, in/decrease the brightest and darkest spots
  
  if(l >= 255 - lThreshold && l < 255) {
    if(r + contrast > 255){
      r = 255;
        } else {
          r += contrast;
        }
        
    if(g + contrast > 255){
          g = 255;
        } else {
          g += contrast;
        }
        
    if(b + contrast > 255){
          b = 255;
        } else {
          b += contrast;
        }
      }
      
    if(l <= 0 + lThreshold && l > 0) {
        
      if(r - contrast < 0) {
          r = 0;
        } else {
          r -= contrast;
        }
        
      if(g - contrast < 0) {
          g = 0;
        } else {
          g -= contrast;
        }
        
      if(b - contrast < 0) {
          b = 0;
        } else {
          b -= contrast;
        }
      }
      
// exposure adjustment - adjust the total brightness of the image
    
      if(r + exposure > 255) {
        r = 255;
      } else if(r + exposure < 0) {
        r = 0;
      } else {
        r += exposure;
      }
      if(g + exposure > 255) {
        g = 255;
      } else if(g + exposure < 0) {
        g = 0;
      } else {
        g += exposure;
      }
      if(b + exposure > 255) {
        b = 255;
      } else if(b + exposure < 0) {
        b = 0;
      } else {
        b += exposure;
      }
    }
  } 
}

function page_trace() {
  //commenting out these functions and replacing with a link to another sketch
  window.open('https://editor.p5js.org/lklesta1/full/vA3nljcRs')
  //button1.hide()
  //button2.hide()
  //button3.hide()
  //button4.hide()
  //button5.show()
  //title1.hide()
  //title2.hide()
  
}

function page_feed() {
  //button1.hide()
  //button2.hide()
  //button3.hide()
  //button4.hide()
  //button5.show()
  //title1.hide()
  //title2.hide()
  window.open('https://editor.p5js.org/cjagadi2/full/AVF4d3TQP')
}

function page_drop() {
  //button1.hide()
  //button2.hide()
  //button3.hide()
  //button4.hide()
  //button5.show()
  //title1.hide()
  //title2.hide()
  window.open('https://editor.p5js.org/arieverett/full/1vW4qaDgh')
}

function go_home() {
  button1.show()
  button2.show()
  button3.show()
  button4.show()
  button5.hide()
  title1.show()
  title2.show()
  contrastSlider.hide()
  exposureSlider.hide()
  volumeSlider.hide()
  titleVolume.hide()
  titleContrast.hide()
  titleBrightness.hide()

}

//we need to build out each game