let penSize = 1;
let penState = 0;
var timerValue = 10;
var startButton;



function setup() {
  createCanvas(800, 450);
  background("lightblue")
  textAlign(LEFT);
  setInterval(timeIt, 1000);
  
  //fins
  fill('yellow')
  ellipse(400,70,75,100)
  ellipse(200,380,160,40)
  ellipse(600,380,160,40)
  //face
  fill('purple')
  ellipse(400,250,450,400)
  //mouth
  fill('pink')
  let circle1 = ellipse(400,300,250)
  //inside mouth
  fill('white')
  ellipse(400,300,200);
  //eyes
  ellipse(300,150,100)
  ellipse(500,150,100)
  //pupils
  fill('black')
  ellipse(300,150,50)
  ellipse(500,150,50)
  //text
  textSize(40)
  fill('orange')
  text('Feed the Fish',10,50)
  textSize(15)
  text('Click and drag in the mouth to feed the fish',10,70)
  
  
  
let button = createButton('HOME')
 button.mousePressed(goToLink);
  button.position(0,430)
  fill("orange")
  textSize(25)
  //text("Feed the Fish By Filling In the Mouth of the Fish", 30, 40)
  textSize(100)



function page_home(){}  
  window.open('https://editor.p5js.org/arieverett/full/XRgiijiGI')
}

function draw() {
  //if (timerValue >= 10) {
    //textSize(10)
    //text("0:" + timerValue, width/2, height/5);
  //}
 //if (timerValue < 10) {
    //text('0:0' + timerValue, width/2-10, height/10-10);
 // }
  if (timerValue == 0) {
    textSize(50)
    text('Game Over', 540,40);
    textSize(15)
    text('Go back to main menu to retry',540, 55)
    
    noLoop();
    
  }
  
  
  
  
  strokeWeight(10)
  if(dist(400,300,mouseX,mouseY)<100) {
  if (mouseIsPressed) {
    if (penState == 0) {
	    line(mouseX, mouseY, pmouseX, pmouseY);
    } 
    
    if (penState == 1) {
	    ellipse(mouseX, mouseY, 10, 10);
    }
    
    if (penState == 2) {
      line(mouseX-5, mouseY-5, mouseX+5, mouseY+5);
      line(mouseX+5, mouseY-5, mouseX-5, mouseY+5);
      
    }
      
    }
  }
}

function keyTyped() {
  if (key == 'c') {
    background(255);
  }

  if (key == 'r') {
    stroke(255, 0, 0);
  }

  if (key == 'b') {
    stroke(0, 0, 255);
  }
  
  if (key == 'x') {
    // x style pen
    penState = 2;
  }
  
  if (key == 'e') {
    // circle pen
    penState = 1;
  }
  
  if (key == 'l') {
    // connected lines
    penState = 0;
  }
}

function keyPressed() {
	if (keyCode == LEFT_ARROW && penSize > 1) {
    penSize -= 1;
  }
  
  if (keyCode == RIGHT_ARROW) {
		penSize += 1;
  }
    
  strokeWeight(penSize);
  
  
  }

function timeIt() {
  if (timerValue > 0) {
    timerValue--;
    
  }
}



function goToLink() {
  window.open('https://editor.p5js.org/arieverett/full/XRgiijiGI')

}

      
      
      