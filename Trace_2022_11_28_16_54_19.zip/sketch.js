// Declared variables
var doorOpen = 0;
var ready = -1;
var endMsg = "";
var c;

// Setup function
function setup() {
  createCanvas(800, 450);
  background('lightblue');
  c = 'blue'
}

// Draw function
function draw() {
  var d = 220;
  // Reset background
	if(mouseX > 0 && mouseX < 120 && mouseY > 0 && mouseY < 30) {
    background('lightblue')
  }
  noStroke();
  // Entrance Box
  textSize(20);
  fill('green');
  rect(0,0, 120, 30);
  fill('yellow');
  text("Entrance", 20, 20);
  
  // Exit Box
  fill('red');
  rect(530,0, 70, 30);
  fill(255);
  text("Exit", 550, 20);
  
// Obstacles and Walls
  fill('orange');
  
  // Big Walls
  rect(120,0, 100, 300);
  rect(120,260, 650, 100);
  rect(340,130, 650, 110);
  rect(430,0, 100, 110);
  
  // End Maze
  rect(340,30, 50, 100);
  rect(530,100, 240, 10);
  rect(550,70, 260, 10);
  rect(530,40, 240, 10);	
  
  fill(d);
  rect(0,560, 20, 20);
  
  // Home Button to go to main page
  button = createButton('HOME')
  button.position(350,450)
  button.size(100)
  button.mousePressed(page_home)
  
  // Start of game
  if(mouseX > 0 && mouseX < 120 && mouseY > 0 && mouseY < 30) {
    ready = 1;
    endMsg = "";
  }
  if(ready == 1) {
    strokeWeight(2);
    stroke('orange');
    line(mouseX, mouseY, pmouseX, pmouseY);
  }
  
  // Win Scenario
  if(ready == 1 && mouseX > 530 && mouseX < 600 && mouseY > 0 && mouseY < 30) {
    // Speed Cheat Check
  	if(dist(pmouseX,pmouseY, mouseX,mouseY) > 20) {
    	ready = 0;
    	endMsg = "Slow Down!";
    	c = 'red';
  	} else {
      endMsg = "You Win!";
    	c = 'blue';
    }
  }
  
  // Opening message
  if(ready == -1) {
    c = 'green';
    endMsg = "Begin Tracing!";
  }
  	textSize(50);
    fill(c);
    text(endMsg, width/4, height/2);
  
  // Lose Scenarios to determine if mouse hits maze walls
	// Big Walls
	// rect(120,0, 100, 300);
  if(mouseX > 120 && mouseX < 220 && mouseY > 0 && mouseY < 300) {
  	ready = 0;
  	endMsg = "Try Again";
    c = 'red'
  }
 	// rect(120,260, 650, 100);
  if(mouseX > 120 && mouseX < 770 && mouseY > 260 && mouseY < 360) {
  	ready = 0;
  	endMsg = "Try Again";
    c = 'red'
  }
	// rect(340,130, 650, 100);
  if(mouseX > 340 && mouseX < 950 && mouseY > 130 && mouseY < 230) {
  	ready = 0;
  	endMsg = "Try Again";
    c = 'red'
  }
  // rect(430,0, 100, 110);
  if(mouseX > 430 && mouseX < 530 && mouseY > 0 && mouseY < 110) {
  	ready = 0;
  	endMsg = "Try Again";
    c = 'red'
  }
  // // End Maze
	// rect(340,30, 50, 100);
  if(mouseX > 340 && mouseX < 390 && mouseY > 30 && mouseY < 130) {
  	ready = 0;
  	endMsg = "Try Again";
    c = 'red'
  }
  // rect(530,100, 240, 10);
  if(mouseX > 530 && mouseX < 770 && mouseY > 100 && mouseY < 110) {
  	ready = 0;
  	endMsg = "Try Again";
    c = 'red'
  }
  // rect(550,70, 260, 10);
  if(mouseX > 550 && mouseX < 810 && mouseY > 70 && mouseY < 80) {
  	ready = 0;
  	endMsg = "Try Again";
    c = 'red'
  }
  // rect(530,40, 240, 10);
  if(mouseX > 530 && mouseX < 770 && mouseY > 40 && mouseY < 50) {
  	ready = 0;
  	endMsg = "Try Again";
    c = 'red'
  }
  
  // Outside the canvas
  if(mouseX > width || mouseX < 0 || mouseY > height || mouseY < 2) {
  	ready = 0;
  	endMsg = "Try Again";
    c = 'red'
  }
  if(mouseX == 0 && mouseY == 0)
    ready = -1;
  
}

// Function to take user to home page when button is clicked
function page_home() {
  window.open('https://editor.p5js.org/arieverett/full/XRgiijiGI')
}